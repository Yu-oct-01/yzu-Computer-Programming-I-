#include <iostream>
using namespace std;

int height[ 50000 ];
int N;
int query;

int findFloor( int last )
{





}

int findCeiling( int first )
{
   for( int i = first; i <= N - 1; i++ )
      if( height[ i ] > query )
         return height[ i ];
   return -1;
}

int main()
{
   while( cin >> N )
   {
      for( int i = 0; i < N; ++i )
         cin >> height[ i ];

      int Q;
      cin >> Q;
      while( Q-- )
      {
         cin >> query;
         int floor = findFloor( N - 1 );
         int ceiling = findCeiling( 0 );
         ( floor == -1 ) ? cout << "X " : cout << floor << " ";
         ( ceiling == -1 ) ? cout << "X\n" : cout << ceiling << endl;
      }
   }
}
#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include <vector>
#include <string>
using namespace::std;

struct Date
{
   int year = 2000;
   int month = 0;
   int day = 0;
};

struct Reservation
{
   char phoneNumber[ 12 ] = ""; // phone number
   char name[ 8 ] = "";         // name
   Date date = Date();          // reservation date
   int time = 0;                // reservation time�G1 for 11:30, 2 for 13:30,
                                //                   3 for 17:45, 4 for 19:45
   int partySize = 0;           // the number of customers for a reservation
   int menu = 0;                // 1 for NT$ 1080, 2 for NT$ 1680, 3 for NT$ 2280
};

struct AvailSeats
{
   Date date = Date(); // a date
   int numAvailSeats[ 5 ] = {};
}; // numAvailSeats[ 1 ]: the number of seats available for lunch #1 (11:30 ~ 13:30)
   // numAvailSeats[ 2 ]: the number of seats available for lunch #2 (13:30 ~ 15:30)
   // numAvailSeats[ 3 ]: the number of seats available for dinner #1 (17:45 ~ 19:45)
   // numAvailSeats[ 4 ]: the number of seats available for dinner #2 (19:45 ~ 21:45)

// loads reservations ( from the file Reservations.dat )
// whose reservation date is not earlier than the current date
void loadReservations( vector< Reservation > &reservations );

// loads availSeats ( from the file AvailSeats.dat )
// whose reservation date is not earlier than the next date of the current date
void loadAvailSeats( vector< AvailSeats > &availSeats );

// initialize availSeats
void adjustAvailSeats( vector< AvailSeats > &availSeats );

// returns true if and only if date1 is earlier than date2
bool earlier( const Date &date1, const Date &date2 );

// returns date1 - date2, i.e., the number of days between date1 and date2
int difference( const Date &date1, const Date &date2 );

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

// make a reservation
void makeReservation( vector< Reservation > &reservations,
                      vector< AvailSeats > &availSeats );

// compute the current date
void computeCurrentDate( Date &currentDate );

// returns true if and only if the specified year is a leap year
bool leapYear( int year );

// input reservation date
void inputDate( vector< AvailSeats > &availSeats, Date &date,
                const Date &currentDate, int partySize );

// returns currentDate + numDays
Date addition( const Date &currentDate, int numDays );

// returns true if and only if there is a j such that availSeats[ i ].numAvailSeats[ j ] >= requiredSeats,
// where availSeats[ i ].date == date
bool hasAvailableSeats( const vector< AvailSeats > &availSeats, const Date date,
                        int requiredSeats );

// returns true if and only if availSeats[ i ].numAvailSeats[ timeCode ] >= requiredSeats,
// where availSeats[ i ].date == date
bool hasAvailableSeats( const vector< AvailSeats > &availSeats, const Date date,
                        int timeCode, int requiredSeats );

// returns a nonnegative integer i if availSeats[ i ].date == date,
// returns -1 otherwise.
int findAvailSeat( const vector< AvailSeats > &availSeats, Date date );

// choose a reservation time
void inputTimeCode( const vector< AvailSeats > &availSeats, const Date date,
                    int &timeCode, int partySize );

// displays partySize, date and time in reservation
void displayReservationInfo( const Reservation &reservation );

// availSeats[ i ].numAvailSeats[ timeCode ] -= requiredSeats,
// where availSeats[ i ].date == date
void decreaseAvailSeats( vector< AvailSeats > &availSeats, const Date date,
                         int timeCode, int requiredSeats );

// input a phoneNumber,
// then displays partySize, date and time in all reservations for phoneNumber
void viewReservation( const vector< Reservation > &reservations );

// returns true if and only if there is an i such that
// reservations[ i ].phoneNumber == phoneNumber
bool exist( const vector< Reservation > &reservations, char phoneNumber[] );

// stores reservations into the file Reservations.dat
void storeReservations( vector< Reservation > &reservations );

// stores availSeats into the file AvailSeats.dat
void storeAvailSeats( vector< AvailSeats > &availSeats );

// array of days per month
int days[ 13 ] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

const int totalNumSeats = 15;

int main()
{
   cout << "Welcome to Zuo Zhe Zuo Sushi Wo Shou Si\n";

   vector< Reservation > reservations; // vector of all reservations
   vector< AvailSeats > availSeats;    // Vector of available seats

   loadReservations( reservations );
   loadAvailSeats( availSeats );
   adjustAvailSeats( availSeats );

   int choice;
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Make Reservation\n"
         << "2. Reservation Enquiry\n"
         << "3. End Program\n";

      do cout << "? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );

      switch( choice )
      {
      case 1:
         makeReservation( reservations, availSeats );
         break;
      case 2:
         viewReservation( reservations );
         break;
      case 3:
         cout << "\nThank you. Goodbye.\n\n";
         storeReservations( reservations );
         storeAvailSeats( availSeats );
         system( "pause" );
         return 0;
      default:
         cerr << "Incorrect Choice!\n";
         break;
      }
   }
}

void loadReservations( vector< Reservation > &reservations )
{
   Date today;
   computeCurrentDate( today );

   ifstream inReservationFile( "Reservations.dat", ios::binary );

   if( !inReservationFile )
   {
      cout << "Reservations.dat could not be opened!\n";
      system( "pause" );
      exit( 1 );
   }





   inReservationFile.close();
}

void loadAvailSeats( vector< AvailSeats > &availSeats )
{
   Date today;
   computeCurrentDate( today );

   ifstream inSeatsFile( "AvailSeats.dat", ios::binary );

   if( !inSeatsFile )
   {
      cout << "AvailSeats.dat could not be opened!\n";
      system( "pause" );
      exit( 1 );
   }





   inSeatsFile.close();
}

void adjustAvailSeats( vector< AvailSeats > &availSeats )
{
   Date today;
   computeCurrentDate( today );

   AvailSeats initSeat;
   for( int i = 1; i <= 4; i++ )
      initSeat.numAvailSeats[ i ] = totalNumSeats;

   for( int i = availSeats.size() + 1; i <= 30; i++ )
   {
      initSeat.date = addition( today, i ); // date = today + i;
      availSeats.push_back( initSeat );
   }
}

bool earlier( const Date &date1, const Date &date2 )
{
   if( date1.year < date2.year )
      return true;
   if( date1.year > date2.year )
      return false;

   if( date1.month < date2.month )
      return true;
   if( date1.month > date2.month )
      return false;

   if( date1.day < date2.day )
      return true;

   return false;
}

int difference( const Date &date1, const Date &date2 )
{





}

int inputAnInteger( int begin, int end )
{
   char string[ 80 ];
   cin.getline( string, 80, '\n' );

   if( strlen( string ) == 0 )
      exit( 0 );

   for( unsigned int i = 0; i < strlen( string ); i++ )
      if( string[ i ] < '0' || string[ i ] > '9' )
         return -1;

   int number = atoi( string );

   if( number >= begin && number <= end )
      return number;
   else
      return -1;
}

void makeReservation( vector< Reservation > &reservations,
                      vector< AvailSeats > &availSeats )
{
   Reservation newReservation;
   cout << endl;
   do cout << "Enter the party size (1~8): ";
   while( ( newReservation.partySize = inputAnInteger( 1, 8 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   inputDate( availSeats, newReservation.date, currentDate,
                          newReservation.partySize );

   inputTimeCode( availSeats, newReservation.date, newReservation.time,
                  newReservation.partySize );

   cout << "\nEnter name: ";
   cin >> newReservation.name;

   cout << "\nEnter phone Number: ";
   cin >> newReservation.phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   do cout << "? ";
   while( ( newReservation.menu = inputAnInteger( 1, 3 ) ) == -1 );

   cout << endl;
   displayReservationInfo( newReservation );

   cout << "\nReservation Completed.\n";

   reservations.push_back( newReservation );

   decreaseAvailSeats( availSeats, newReservation.date, newReservation.time,
                       newReservation.partySize );
}

bool leapYear( int year )
{
   return ( year % 400 == 0 || ( year % 4 == 0 && year % 100 != 0 ) );
}

void computeCurrentDate( Date &currentDate )
{
   tm structuredTime;
   time_t rawTime = time( 0 );
   localtime_s( &structuredTime, &rawTime );

   currentDate.year = structuredTime.tm_year + 1900;
   currentDate.month = structuredTime.tm_mon + 1;
   currentDate.day = structuredTime.tm_mday;
}

void inputDate( vector< AvailSeats > &availSeats, Date &date,
                const Date &currentDate, int partySize )
{





}

Date addition( const Date &currentDate, int numDays )
{
   if( leapYear( currentDate.year ) )
      days[ 1 ] = 29;

   Date date;
   date = currentDate;





   return date; // reference return to create an lvalue
}

bool hasAvailableSeats( const vector< AvailSeats > &availSeats, const Date date,
                        int requiredSeats )
{
   int pos = findAvailSeat( availSeats, date );





}

int findAvailSeat( const vector< AvailSeats > &availSeats, Date date )
{





}

void inputTimeCode( const vector< AvailSeats > &availSeats, const Date date,
                    int &timeCode, int partySize )
{





}

bool hasAvailableSeats( const vector< AvailSeats > &availSeats, const Date date,
                        int timeCode, int requiredSeats )
{
   int pos = findAvailSeat( availSeats, date );





}

void displayReservationInfo( const Reservation &reservation )
{
   cout << reservation.partySize << " guests  ";

   cout << reservation.date.year << "/";

   if( reservation.date.month < 10 )
      cout << '0';
   cout << reservation.date.month << "/";

   if( reservation.date.day < 10 )
      cout << '0';
   cout << reservation.date.day;

   char times[ 5 ][ 8 ] = { "", "11:30", "13:30", "17:45", "19:45" };
   cout << "  " << times[ reservation.time ] << endl;
}

void decreaseAvailSeats( vector< AvailSeats > &availSeats, const Date date,
                         int timeCode, int requiredSeats )
{
   int pos = findAvailSeat( availSeats, date );
   if( pos >= 0 ) // found
      availSeats[ pos ].numAvailSeats[ timeCode ] -= requiredSeats;
}

void viewReservation( const vector< Reservation > &reservations )
{
   if( reservations.size() == 0 )
   {
      cout << "\nNo reservations!\n";
      return;
   }

   char phoneNumber[ 12 ];
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   if( !exist( reservations, phoneNumber ) )
   {
      cout << "\nYou have no reservations!\n";
      return;
   }

   cout << endl;
   int count = 0;
   for( size_t i = 0; i < reservations.size(); ++i )
      if( strcmp( reservations[ i ].phoneNumber, phoneNumber ) == 0 )
      {
         cout << setw( 2 ) << ++count << ". ";
         displayReservationInfo( reservations[ i ] );
      }
}

bool exist( const vector< Reservation > &reservations, char phoneNumber[] )
{





}

void storeReservations( vector< Reservation > &reservations )
{
   ofstream outReservationFile( "Reservations.dat", ios::binary );

   if( !outReservationFile )
   {
      cout << "Reservations.dat could not be opened!\n";
      system( "pause" );
      exit( 1 );
   }

   for( size_t i = 0; i < reservations.size(); i++ )
      outReservationFile.write( reinterpret_cast< const char * >( &reservations[ i ] ),
                                sizeof( Reservation ) );

   outReservationFile.close();
}

void storeAvailSeats( vector< AvailSeats > &availSeats )
{
   ofstream outSeatsFile( "AvailSeats.dat", ios::binary );

   if( !outSeatsFile )
   {
      cout << "AvailSeats.dat could not be opened!\n";
      system( "pause" );
      exit( 1 );
   }

   for( size_t i = 0; i < availSeats.size(); i++ )
      outSeatsFile.write( reinterpret_cast< const char * >( &availSeats[ i ] ),
                          sizeof( AvailSeats ) );

   outSeatsFile.close();
}